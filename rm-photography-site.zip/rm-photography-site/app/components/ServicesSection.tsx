"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";

const SERVICES = [
  {
    title: "Families",
    copy: "Real connection over posed perfection — capturing how your family actually feels together.",
  },
  {
    title: "Seniors",
    copy: "A confident, candid send-off to this chapter, shot wherever you feel most like yourself.",
  },
  {
    title: "Engagements",
    copy: "The in-between moments — the laughter, the nerves, the quiet looks — before the big day.",
  },
  {
    title: "Weddings",
    copy: "Documenting your day as it unfolds, so you can relive every detail years from now.",
  },
  {
    title: "Golden Hour Light",
    copy: "Sessions timed around natural light for warm, soft, true-to-life color in every frame.",
  },
  {
    title: "Candid Storytelling",
    copy: "Not just pictures — memories, exactly as they happened, kept just as they were.",
  },
];

export default function ServicesSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section
      ref={ref}
      style={{
        padding: "8vh 6vw",
        background: "#FAF6F0",
      }}
    >
      <motion.span
        initial={{ opacity: 0, y: 24 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.6, ease: [0.25, 0, 0, 1] }}
        style={{
          fontFamily: "var(--font-inter)",
          fontSize: "0.65rem",
          letterSpacing: "0.25em",
          textTransform: "uppercase",
          color: "#B8843A",
          display: "block",
          marginBottom: "1rem",
        }}
      >
        What I Capture
      </motion.span>
      <motion.h2
        initial={{ opacity: 0, y: 24 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.6, delay: 0.1, ease: [0.25, 0, 0, 1] }}
        style={{
          fontFamily: "var(--font-playfair)",
          fontWeight: 400,
          fontSize: "clamp(2rem, 4vw, 3.5rem)",
          color: "#2D2A26",
          marginBottom: "4rem",
          maxWidth: 700,
        }}
      >
        Sessions built around your story, not a template.
      </motion.h2>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
          gap: "2.5rem",
        }}
      >
        {SERVICES.map((s, i) => (
          <motion.div
            key={s.title}
            initial={{ opacity: 0, y: 24 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{
              duration: 0.6,
              delay: 0.1 * i,
              ease: [0.25, 0, 0, 1],
            }}
            style={{
              borderTop: "1px solid rgba(184,132,58,0.3)",
              paddingTop: "1.5rem",
            }}
          >
            <h3
              style={{
                fontFamily: "var(--font-playfair)",
                fontSize: "1.4rem",
                color: "#2D2A26",
                marginBottom: "0.6rem",
              }}
            >
              {s.title}
            </h3>
            <p
              style={{
                fontFamily: "var(--font-inter)",
                fontWeight: 300,
                fontSize: "0.95rem",
                color: "#5C564C",
                lineHeight: 1.6,
              }}
            >
              {s.copy}
            </p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
