"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";

export default function ClosingCTA() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section
      id="contact"
      ref={ref}
      style={{
        position: "relative",
        padding: "14vh 6vw",
        background: "#1A1410",
        textAlign: "center",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        overflow: "hidden",
      }}
    >
      <div
        style={{
          position: "absolute",
          inset: 0,
          background:
            "radial-gradient(ellipse at center, rgba(216,168,87,0.12) 0%, transparent 70%)",
          pointerEvents: "none",
        }}
      />
      <motion.span
        initial={{ opacity: 0, y: 24 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.6, ease: [0.25, 0, 0, 1] }}
        style={{
          fontFamily: "var(--font-inter)",
          fontSize: "0.65rem",
          letterSpacing: "0.25em",
          textTransform: "uppercase",
          color: "#D8A857",
          marginBottom: "1.4rem",
        }}
      >
        Let&apos;s Tell Your Story
      </motion.span>
      <motion.h2
        initial={{ opacity: 0, y: 24 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.6, delay: 0.1, ease: [0.25, 0, 0, 1] }}
        style={{
          fontFamily: "var(--font-playfair)",
          fontWeight: 400,
          fontSize: "clamp(2.2rem, 5vw, 4.5rem)",
          color: "#FFFFFF",
          lineHeight: 1.15,
          marginBottom: "1.4rem",
        }}
      >
        These aren&apos;t just pictures.
        <br />
        <span style={{ fontStyle: "italic", color: "#EDE6DB" }}>
          They&apos;re memories, exactly as they were.
        </span>
      </motion.h2>
      <motion.p
        initial={{ opacity: 0, y: 24 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.6, delay: 0.2, ease: [0.25, 0, 0, 1] }}
        style={{
          fontFamily: "var(--font-inter)",
          fontWeight: 300,
          color: "#C9C2B6",
          maxWidth: 480,
          marginBottom: "2.4rem",
        }}
      >
        Send a message and let&apos;s plan a session that feels like you —
        warm, real, and worth remembering.
      </motion.p>
      <motion.a
        href="mailto:rmphoto25@gmail.com"
        initial={{ opacity: 0, y: 24 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.6, delay: 0.3, ease: [0.25, 0, 0, 1] }}
        whileHover={{ backgroundColor: "#1A1410", color: "#D8A857" }}
        style={{
          display: "inline-block",
          border: "1px solid #D8A857",
          color: "#D8A857",
          fontFamily: "var(--font-inter)",
          fontWeight: 500,
          fontSize: "0.7rem",
          letterSpacing: "0.18em",
          textTransform: "uppercase",
          padding: "0.9rem 2.6rem",
          position: "relative",
          zIndex: 1,
        }}
      >
        Get In Touch
      </motion.a>
    </section>
  );
}
