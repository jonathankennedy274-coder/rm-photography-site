"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";

const PACKAGES = [
  { label: "Families", value: "Starting from $200" },
  { label: "Seniors", value: "Starting from $200" },
  { label: "Engagements", value: "Starting from $300" },
  { label: "Weddings", value: "Starting from $1,250" },
  { label: "Session Length", value: "45–90 minutes, by package" },
  { label: "Delivery", value: "Digital gallery, online for download" },
  { label: "Turnaround", value: "2–4 weeks" },
  { label: "Location", value: "Omaha area & surrounding counties" },
];

export default function InvestmentSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section
      ref={ref}
      style={{
        padding: "8vh 6vw",
        background: "#F2EAD9",
      }}
    >
      <motion.span
        initial={{ opacity: 0, y: 24 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.6, ease: [0.25, 0, 0, 1] }}
        style={{
          fontFamily: "var(--font-inter)",
          fontSize: "0.65rem",
          letterSpacing: "0.25em",
          textTransform: "uppercase",
          color: "#B8843A",
          display: "block",
          marginBottom: "1rem",
        }}
      >
        Services &amp; Investment
      </motion.span>
      <motion.h2
        initial={{ opacity: 0, y: 24 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.6, delay: 0.1, ease: [0.25, 0, 0, 1] }}
        style={{
          fontFamily: "var(--font-playfair)",
          fontWeight: 400,
          fontSize: "clamp(2rem, 4vw, 3.5rem)",
          color: "#2D2A26",
          marginBottom: "3rem",
          maxWidth: 700,
        }}
      >
        Simple pricing, no surprises.
      </motion.h2>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(2, 1fr)",
          maxWidth: 760,
        }}
      >
        {PACKAGES.map((row, i) => (
          <motion.div
            key={row.label}
            initial={{ opacity: 0, y: 16 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{
              duration: 0.5,
              delay: 0.06 * i,
              ease: [0.25, 0, 0, 1],
            }}
            style={{
              gridColumn: "1 / -1",
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              borderBottom: "1px solid rgba(45,42,38,0.1)",
              padding: "1rem 0",
            }}
          >
            <span
              style={{
                fontFamily: "var(--font-inter)",
                fontSize: "0.85rem",
                letterSpacing: "0.05em",
                textTransform: "uppercase",
                color: "#B8843A",
              }}
            >
              {row.label}
            </span>
            <span
              style={{
                fontFamily: "var(--font-inter)",
                fontWeight: 300,
                fontSize: "0.95rem",
                color: "#3A352E",
              }}
            >
              {row.value}
            </span>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
