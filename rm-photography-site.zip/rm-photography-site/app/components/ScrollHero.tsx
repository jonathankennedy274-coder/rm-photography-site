"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";

// Drop her downloaded images into /public/images and list the filenames
// here in the order you want the hero to scrub through as the visitor scrolls.
const FRAMES = [
  "/images/home/T-8-8e7ced37-1500.jpg",
  "/images/home/AlexisCooper-47-daf98ad1-1500.jpg",
  "/images/home/Kriefels-18-e6153319-1500.jpg",
  "/images/home/T-5-7ccb6fc4-1500.jpg",
  "/images/home/Aurora-60-911fe8ce-1500.jpg",
  "/images/home/AlexisCooper-26-4cfbb19a-1500.jpg",
];

export default function ScrollHero() {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imagesRef = useRef<HTMLImageElement[]>([]);
  const currentIdxRef = useRef(0);
  const rafRef = useRef<number | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;

    function resizeCanvas() {
      const cw = window.innerWidth;
      const ch = window.innerHeight;
      canvas!.width = cw * dpr;
      canvas!.height = ch * dpr;
      canvas!.style.width = cw + "px";
      canvas!.style.height = ch + "px";
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    function drawCover(img: HTMLImageElement) {
      const cw = window.innerWidth;
      const ch = window.innerHeight;
      ctx!.fillStyle = "#000";
      ctx!.fillRect(0, 0, cw, ch);
      const iw = img.naturalWidth;
      const ih = img.naturalHeight;
      if (!iw || !ih) return;
      const scale = Math.max(cw / iw, ch / ih);
      const dw = iw * scale;
      const dh = ih * scale;
      const dx = (cw - dw) / 2;
      const dy = (ch - dh) / 2;
      ctx!.drawImage(img, dx, dy, dw, dh);
    }

    resizeCanvas();

    let loadedCount = 0;
    const imgs: HTMLImageElement[] = FRAMES.map((src, i) => {
      const img = new Image();
      img.src = src;
      img.onload = () => {
        loadedCount++;
        if (i === 0) drawCover(img);
        if (loadedCount === FRAMES.length) setLoaded(true);
      };
      return img;
    });
    imagesRef.current = imgs;

    function loop() {
      const top = container!.getBoundingClientRect().top;
      const scrollRange = container!.offsetHeight - window.innerHeight;
      const progress = Math.max(0, Math.min(1, -top / Math.max(1, scrollRange)));
      const target = Math.round(progress * (FRAMES.length - 1));
      if (target !== currentIdxRef.current && imagesRef.current[target]?.complete) {
        currentIdxRef.current = target;
        drawCover(imagesRef.current[target]);
      }
      rafRef.current = requestAnimationFrame(loop);
    }
    rafRef.current = requestAnimationFrame(loop);

    function onResize() {
      resizeCanvas();
      const img = imagesRef.current[currentIdxRef.current];
      if (img && img.complete) drawCover(img);
    }
    window.addEventListener("resize", onResize);

    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      window.removeEventListener("resize", onResize);
    };
  }, []);

  return (
    <div ref={containerRef} style={{ height: "300vh", position: "relative" }}>
      <div
        style={{
          position: "sticky",
          top: 0,
          width: "100vw",
          height: "100vh",
          overflow: "hidden",
          background: "#000",
        }}
      >
        <canvas ref={canvasRef} style={{ display: "block" }} />
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            flexDirection: "column",
            justifyContent: "flex-end",
            padding: "0 6vw 8vh",
            background:
              "linear-gradient(to top, rgba(20,14,8,0.85) 0%, rgba(20,14,8,0.3) 50%, transparent 100%)",
          }}
        >
          <motion.span
            initial={{ opacity: 0, y: 16 }}
            animate={loaded ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.8, duration: 0.6, ease: "easeOut" }}
            style={{
              fontFamily: "var(--font-inter)",
              fontSize: "0.65rem",
              letterSpacing: "0.25em",
              textTransform: "uppercase",
              color: "#D8A857",
              marginBottom: "1.2rem",
            }}
          >
            Omaha, Nebraska
          </motion.span>
          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={loaded ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.95, duration: 0.6, ease: "easeOut" }}
            style={{
              fontFamily: "var(--font-playfair)",
              fontWeight: 400,
              fontSize: "clamp(2.4rem, 6vw, 5.5rem)",
              color: "#FFFFFF",
              lineHeight: 1.05,
              marginBottom: "1rem",
            }}
          >
            RM Photography
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={loaded ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 1.1, duration: 0.6, ease: "easeOut" }}
            style={{
              fontFamily: "var(--font-inter)",
              fontWeight: 300,
              fontSize: "1.05rem",
              color: "#EDE6DB",
              maxWidth: 460,
              marginBottom: "2.2rem",
            }}
          >
            Authentic moments, natural light, and real emotion — captured for
            families, couples, and seniors around Omaha.
          </motion.p>
          <motion.a
            href="#contact"
            initial={{ opacity: 0, y: 16 }}
            animate={loaded ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 1.25, duration: 0.6, ease: "easeOut" }}
            style={{
              display: "inline-block",
              background: "#D8A857",
              color: "#1A1410",
              fontFamily: "var(--font-inter)",
              fontWeight: 500,
              fontSize: "0.7rem",
              letterSpacing: "0.18em",
              textTransform: "uppercase",
              padding: "0.9rem 2.6rem",
              width: "fit-content",
              pointerEvents: "auto",
            }}
          >
            Let&apos;s Connect
          </motion.a>
        </div>
      </div>
    </div>
  );
}
