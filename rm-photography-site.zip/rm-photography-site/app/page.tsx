import ScrollHero from "./components/ScrollHero";
import ServicesSection from "./components/ServicesSection";
import InvestmentSection from "./components/InvestmentSection";
import ClosingCTA from "./components/ClosingCTA";

export default function Home() {
  return (
    <main>
      <ScrollHero />
      <ServicesSection />
      <InvestmentSection />
      <ClosingCTA />
    </main>
  );
}
